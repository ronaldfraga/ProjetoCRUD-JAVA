package util;

public class DBConfig {
    public static final String URL = "jdbc:mysql://localhost:3306/meubanco";
    public static final String USER = "xfragax";
    public static final String PASSWORD = "0115";
}
